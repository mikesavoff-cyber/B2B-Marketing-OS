How to crowd and confidence and conversations fit into this. So first up, this pyramid gives you a model as you build your way up. But as we're building this out, as we're thinking about the three things you have to know and the four numbers you need to know. It's important that you realize just because you got success once doesn't mean you go on to the next stage of this pyramid.

You want to make sure that we have confidence ourselves, that we have a good result before we go on to try everything and hit success twice before you declare a win. And it's really important, as you do this, that you're not making little, tiny, itty bitty steps at the base of the pyramid. You won't discover interesting insights if you're testing a wealth manager audience versus an investment manager audience, they're basically the same thing.

Or if you're testing quality assurance, one job roles versus quality assurance two job rolls. You're not learning anything here. But if you test a wealth manager versus a, I don't know, a mortuary technician, that's a big difference. What are you selling? I don't know, it sounds very grim, but whatever it is you're selling, you're learning who actually is interested here, and you're figuring out the crowd.

You want to build this around. So begin with really big swings, really crazy. Different crowd. And then as you make your way up this pyramid, you're making more conservative bets because as a marketer, you can think of a this appeal versus that appeal is going to work better just because I mean we're here at six. So marketing you know what you're about.

But as you're doing this as you're making your way through building their system, they're really four distinct pieces. We're going to be talking about for the rest of this course. And we're going to walk you through building these four pieces as the base to making your way through every marketing engine. And the first thing you have to do is you have to figure out how many folks are crossing that interest gap and who's your crowd.

And so we do that with minimum viable sprints. I've already talked about them. We'll talk more about them in the next course. But this is going to give you the insight you need on your audience. But it's important when we're making big swings it's high risk. So we only risk a little bit on our side. They come very quickly.

They're only $100. Spend on these sprints to understand is this an audience that I want. And you're going to discard most of the people who you test minimum viable sprints on. They're not going to be a good fit. That's okay. Because if you took, I don't know, two weeks to run five minimum viable sprints, you're out 500 bucks.

This is not an appreciable cost. If it tells you this audience is three times better than the audience who we thought was going to be our champion. That's the kind of insights we're looking to generate here. And then from there we go to lead generation. Now lead generation. Here I'm using a very specific terminology which is lead generation built in platform.

Any lead is lead generation. But here we're talking about on meta, on YouTube, on LinkedIn. People fill out a form on that platform and don't go to your website. And there's reasons why we do this. One is unless you've taken CXL marketing course on Data and analytics, course marketing course on Google Analytics for CXL marketing course on growth marketing, and you understand how to pipe the back end of your website.

And by the way, you should take that if you haven't. But most people haven't taken all of those yet. And so when they build a landing page and when they build a website, there's going to be gaps. Literally every single client cloud teamers has worked with, from really big companies to really small ones, have had something wrong with how they do attribution to Facebook pixels not writer in product activations being tracked wrong or wherever it is.

There's some gap here. So if we go straight from audience testing into landing page sign up and all of that and we're missing data, we won't really understand how to attribute this properly. So while you're fixing that and building out and realizing, oh no, I need better attribution for my Google ads or whatever, lead generation on platform helps you understand the entire journey because they've never left the ad platform.

So here we look to start consideration. We look to get people to sign up. You need to spend more here because we have to get more clicks to get enough sign up to have a statistical relevance. But this is going to help us understand what's the right thing to tell the crowd who we found. And then finally, when we know what that is.

Now we're building landing pages and running full round of experiments from awareness all the way to crossing this attention gap. And here we have to spend even still a little more. And what we're looking at, how many folks activate into an actual sales discussion. And of these people we're going to compare them versus what we see for our lead generation campaigns.

Some clients find generating leads directly on platform is always more efficient. Some businesses find that generating leads on platforms always more efficient. And some businesses buy that lead generation ad bring lower quality leads, and they're actually better off getting fewer, higher quality leads on their website, which is going to work for you as part of we're going to be answering as we build this engine.

And then finally at the end, how many people cross the decision gap? How many people are giving you money? And how do I scale this? How do we make this something that is not? If I spend $100, I make 500\. But if I spend $10,000, I make 50,000. And you might look at this and say, Trevor, four months, three months.

That's a long time to go building out a marketing engine. I tend to think a month or two months in advance. How do I make this part of my business practice? Well, I think there's two ways to think of this. And one of them is if you could spend $5,000 to make a million, would you? I would, I would, and probably you would too.

And if you look at what the spend is here in terms of just advertising and what you're doing to learn all of these things, spending like five, seven grand. The other part is this is repeatable. So if you are reporting to a VP of marketing or a CEO or whomever it is who's holding you responsible for making revenue happen in their company.

There are a few things you can do that make you more of an expert and more dependable than being able to say to everybody else you talked to, look, we did this. We went through these steps. It's making us money, and now we're building the next one. So each of these four pieces, each of these deliverables to make a marketing engine consistent, is going to be the focus of the rest of this course.

And the first thing we have to learn about is minimum viable marketing spreads. So let's talk about them. So a minimum viable sprint answer is who is my crowd. The goal here is to see, of all the potential people who you might want to talk to about what it is you are building, what it is you were selling, who are the ones who care most about what it is you're going to do?

Now, a Legion ad is what actually drives conversation, and we'll talk about that more in a little minute. And then finally, when we do those experiment rounds and building full landing pages, we're seeing what convert them into actual buyers. But the focus right now is going to be on who is your crowd. We're at the base of this pyramid and you'll be sending traffic to your website, but we don't really care what that traffic does, so don't focus right now on we ran these minimum viable sprints and nobody signed up.

Yes, that's almost a guarantee. You're not making money yet. You're paying to learn who's going to be engaged. And because we're taking big swings here and trying super different audiences, if they go to your home page, they're going to be kind of confused because the home page is hand crafted for any of these people. Eventually, we're going to make landing pages that find that best crowd and bring them in.

But right now we're just seeing who's interested. We're measuring the click. We're building the base of the pyramid. Don't worry about the rest yet. We're not trying to build it. So we need to talk about how to build and buy an ad. Now, if you've taken the course from CXL on buying ads on Facebook or buying ads on Google, some of this is going to look pretty familiar.

But also some of it's going to look different. Come on, let me show it to you.  
