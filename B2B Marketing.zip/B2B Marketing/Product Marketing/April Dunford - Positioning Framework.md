# **April Dunford — Complete Framework Reference**

## **Table of Contents**

1. Core Positioning Philosophy  
2. When to Use This Methodology  
3. The Five Positioning Components (in sequence)  
4. The Positioning Process (step by step)  
5. The Positioning Canvas  
6. The Sales Pitch Framework (8 Components)  
7. Mapping Sales Pitch to Positioning  
8. The Messaging Document (8 Sections)  
9. April as Strategic Advisor — How to Apply This in the Brain

---

## **1\. Core Positioning Philosophy**

Positioning is the context that makes your product's value obvious to your target customers. It is the underpinning of all messaging. Everything in messaging must align with positioning.

Positioning is NOT messaging. Positioning is the strategic foundation. Messaging is what you build on top of it. Companies that try to write messaging without completed positioning are decorating a building without a foundation.

Positioning is NOT a tagline, a value proposition statement, or a mission statement. It is a strategic framework that answers: what are we, for whom, and why does it matter in a world where alternatives exist?

The key insight: Positioning is determined by the competitive context you choose to put yourself in. The context — market category — changes everything: which alternatives buyers consider, which criteria they use to evaluate, what price point they expect, and what capabilities they think they need.

---

## **2\. When to Use This Methodology**

This methodology was built for:

* B2B tech companies  
* Products that are in-market with a certain amount of traction (you understand patterns around who loves you and why)  
* Companies sold using a sales team at some stage

The methodology works less well for:

* Pre-launch (use it to craft a positioning thesis, not final positioning)  
* Completely zero-touch GTM without any sales motion — those teams won't understand enough about what alternatives customers truly consider, the decision-making process, and stakeholders unless they do formal research

A critical note: Filling in a positioning exercise on your own might be an interesting intellectual exercise, but it is no substitute for working through the process with a team. The team exercise surfaces the real competitive alternatives and value themes. Solo positioning is usually wrong.

---

## **3\. The Five Positioning Components (in sequence — order matters)**

### **Component 1: Competitive Alternatives**

If you didn't exist, what would customers use instead?

Include:

* Status quo solutions like "manual processes," "spreadsheets," "doing nothing"  
* Direct competitors that appear on actual customer short lists

Do NOT include:

* Theoretical competitors — companies that could compete but never make a customer's short list

Group the competitors by their approach to the problem, not by company name. You'll likely find 2–4 approaches that multiple vendors represent.

Why this comes first: Everything else flows from this. Your distinct capabilities are only distinct relative to these alternatives. Your value is only differentiated relative to what these alternatives can deliver. Your market category is the context that makes your advantages obvious versus these alternatives.

### **Component 2: Distinct Capabilities**

The features of your product and the capabilities of your company that the alternatives do not have.

It's OK if not all capabilities are distinct from every alternative — list them all anyway. The goal is an honest inventory of what makes you different from each alternative approach.

Includes:

* Product features  
* Company capabilities (expertise, relationships, processes, data)  
* Things the team can do that others can't

This is raw material for differentiation — not messaging.

### **Component 3: Differentiated Value**

The business value your product or company can deliver that the alternatives cannot. Should have 1–3 themes.

For each distinct capability, ask: "So what? Why does a customer care about this feature? What does this capability enable for a customer's business?" Keep asking until you reach a business outcome.

Group value into 1–4 buckets or "themes" that capture the category of business impact.

Critical distinction: Value themes are NOT messaging. They are strategic inputs. The translation from value theme to customer-facing message is a separate creative act. Don't conflate them.

### **Component 4: Best-Fit Accounts**

The characteristics of a target account that make them really care a lot about the value that only you can deliver.

Looking at the value themes, ask: "What are the characteristics of a company that makes them care a lot about this specific value?"

Also define bad-fit accounts explicitly — they tell you as much about your positioning as good-fit accounts do.

Examples of characteristics: company size, industry, current tech stack, growth stage, team structure, specific workflows they have, problems they're actively trying to solve, budget available.

### **Component 5: Market Category**

The context you position your product or company in. The starting point for prospects trying to figure out what you do.

This is determined last — after you understand your alternatives, capabilities, value, and best-fit accounts — because the right category is the one that makes your value obvious to your best-fit accounts.

The market category activates a specific set of buyer expectations:

* Which competitive alternatives they'll put on the short list  
* Which evaluation criteria they'll apply  
* What price they expect to pay  
* What capabilities they assume you have

Choosing wrong makes your value invisible. Choosing right makes your value obvious. This is a strategic weapon, not a label.

---

## **4\. The Positioning Process (Step by Step)**

### **Before You Start**

Considerations:

* Perform a positioning readiness check  
* Ensure you are positioning for customers (not for internal comfort or investor narrative)  
* Define what you intend to position (product, company, both)  
* Agree on the champion persona you will target

Preparing for the exercise:

* Form a positioning team (cannot be done solo effectively)  
* Eliminate bad-fit customers from the analysis — focus only on good-fit customers  
* Let go of your positioning baggage — previous positioning decisions are inputs, not anchors  
* Align your positioning vocabulary before the exercise starts — everyone on the team should be using the same definitions for words like "customer," "segment," "alternative," "feature," and "value"

### **Step 1: List True Competitive Alternatives and Group by Approach**

Include the status quo you replace and competitors that land on a short list. Do NOT include theoretical competitors. Group competitors by their approach to the problem — you'll likely find 2–4 clusters.

### **Step 2: List Distinct Capabilities**

Product features and company capabilities that alternatives don't have. OK if not distinct from every alternative.

### **Step 3: Map Capabilities to 1–4 Value Themes**

For each capability: "So what? Why does a customer care? What does this enable for their business?" Group into themes.

### **Step 4: Determine Best-Fit Account Characteristics**

From value themes: "What are the characteristics of a company that cares a lot about the value only we can deliver?"

### **Step 5: Determine the Best Market Category**

What context makes the value obvious to best-fit accounts?

### **After Positioning**

1. Test positioning with a sales pitch  
2. Translate positioning into a messaging document

---

## **5\. The Positioning Canvas**

One-page summary of completed positioning work. Use as the strategic foundation for the messaging document.

Fields:

* Product or Company (what is being positioned)  
* Date Completed  
* Competitive Alternative Approaches (Approach \#1, \#2, \#3 — grouped by method)  
* Distinct Capabilities (all of them)  
* Differentiated Value (Value Theme \#1, \#2, \#3 with supporting capabilities per theme)  
* Best-Fit Customer (account characteristics)  
* Market Category

### **SnoutDesk Positioning Canvas Example**

Product: SnoutDesk Market Category: Business Management Software for Pet Services

Competitive Alternative Approaches:

* Approach 1: Do not fully track customers and services — use free tools for booking, track repeat clients using spreadsheet or pen and paper  
* Approach 2: Generic Small Business CRMs (Zoho, HubSpot most often seen) — used for customer tracking and email  
* Approach 3: Pet services software (CanineCal, FurFlow most often seen) — provide scheduling with very basic marketing capabilities

Distinct Capabilities: Automate Reminders, Marketing tools for reputation management, Automated review reminders, review alerts across any review platform, customer and services data tracking, utilization reporting, accurate expense tracking, AI-powered dynamic pricing

Differentiated Value:

* Value Theme 1: Increase revenue by up to 15% by attracting more new business and increasing repeat business (capabilities: Book and pay online, Automated email reminders, marketing tools, alerts)  
* Value Theme 2: Understand your business to drive improved profitability (capabilities: Customer and services data tracking, utilization reporting, accurate expense tracking, AI-powered dynamic pricing)

Best-Fit Accounts: Mid to large-sized pet services businesses with more than 2 employees, has a retail presence Bad-Fit Accounts: Solo pet services practitioners, online only businesses

---

## **6\. The Sales Pitch Framework (8 Components)**

Core premise: Positioning must be tested through a sales pitch. The pitch is how you find out if positioning actually lands with real buyers. The pitch turns strategic positioning inputs into a story that moves people through a buying decision.

### **THE SETUP — The Market**

These three components establish the context before you introduce your product. The prospect should be nodding by the end of Perfect World — before they've heard your solution.

Component 1: Insight Your point of view on the market — what you understand about the situation, customers, and solutions that other vendors don't. The insight is the reason you built what you built the way you built it. The reason why you can deliver value that competitors cannot.

Prospects need to understand the insight before they can understand the importance of your differentiated value.

Your insight is tightly tied to your Differentiated Value from positioning. If you can't articulate why you see the market differently than everyone else, your differentiated value won't land.

Component 2: Alternative Approaches (pros and cons) Present as a table or chart listing the alternative ways of solving the problem and the pros and cons of each.

This step SHOULD BE a discovery conversation with the prospect — not a monologue. Ask them what they currently use, what they like about it, what frustrates them. Let them articulate the shortcomings of the alternatives in their own words. This is more powerful than you listing the cons yourself.

Maps directly to the Competitive Alternatives component of positioning.

Component 3: Perfect World The conclusion of the discovery conversation. A list of characteristics of a "perfect" solution for your target customer.

This should emerge naturally from the alternatives conversation. If alternatives conversation goes well, the prospect will articulate what they wish the alternatives could do. Perfect World captures those characteristics — and they should map directly to your differentiated value themes.

If done well, the prospect is asking "does something like this actually exist?" before you've introduced your product.

### **THE FOLLOW-THROUGH — Your Solution**

Component 4: Introduction Introduce the company and the product. Use your Market Category as the starting point ("we're a \[market category\] that...").

Keep this brief — the setup has done the context work. This is the handoff from "here's the problem in the market" to "here's what we've built."

Component 5: Differentiated Value The meat of the pitch. Walk through each of the value themes and the key capabilities that enable them.

Maps directly to Differentiated Value from positioning. This is frequently done using a demo — show how the product delivers on each value theme rather than just claiming it.

Component 6: Proof Third-party validation that you can do what you say you can do. Typically a customer case study.

The proof must be specific to the value you claimed — generic social proof ("customers love us") doesn't work here. The proof should show a customer like your prospect achieving the value you described.

Component 7: Objections (optional) Handle common important objections — migration, deployment, pricing structure, integration, security.

This isn't mapped to positioning per se but should address the concern that the prospect may not be able to realize your differentiated value. The objection is rarely "I don't want this value" — it's "I'm not sure I can actually get this value given our situation."

Component 8: The Ask What would you like the prospect to do next? Be specific. Could be: follow-on meeting, requirements session with IT, sending a proposal.

Don't leave a conversation without a defined next step.

---

## **7\. Mapping Sales Pitch to Positioning**

| Pitch Component | Positioning Component |
| ----- | ----- |
| Insight | Differentiated Value (the reason you built it this way and can deliver what others can't) |
| Alternative Approaches | Competitive Alternatives |
| Perfect World | Differentiated Value (what good looks like) |
| Introduction | Market Category |
| Differentiated Value | Differentiated Value |
| Proof | Customer who achieved the differentiated value |
| Objections | Ability to realize differentiated value in the prospect's context |
| The Ask | Next step in sales process |

### **SnoutDesk Sales Pitch Storyboard Example**

Insight: Growing a pet business depends on being able to attract new customers, getting more business from existing customers, and improving profitability. Most growing pet services businesses struggle with all three.

Competitive Alternative Approaches:

* Do not fully track customers (pro: free, easy; con: can't track customers or profit, no way to improve marketing)  
* Generic Small Business CRMs (pro: feature-rich, scalable; con: many irrelevant features, lacking pet-specific features, need to customize workflows)  
* Pet services software (pro: pet-specific data/workflows; con: can't scale for growing businesses, lacking deep marketing tools, no profit tracking)

Perfect World:

* Specifically designed to help growing pet businesses market to new customers and grow repeat business  
* Gives owners a clear view of profitability so they can improve it

Introduction: Introducing SnoutDesk — Business Management Software for Growing Pet Services Businesses.

Differentiated Value:

* Value Theme 1: Increase revenue by up to 15% by attracting more new business and increasing repeat business (Book and pay online, automated email reminders, marketing tools)  
* Value Theme 2: Understand your business to drive improved profitability (customer and services data tracking, utilization reporting, accurate expense tracking, AI-powered dynamic pricing)

Proof: Wild & Wagging Case Study

Unspoken Objections: Worry about how long and difficult it will be to deploy the solution. Show the typical project timeline and highlight service and training resources.

The Ask: Have a second meeting with IT to get requirements needed to produce an accurate quote.

---

## **8\. The Messaging Document (8 Sections)**

Core premise: The messaging document translates positioning into approved, consistent language that anyone on the team can use to create marketing and sales materials without re-inventing the message or drifting from positioning.

Four problems it solves:

1. Wasting time recreating messages for every new tactic  
2. Messaging drift over time creating inconsistency  
3. New employees not understanding the positioning context behind messages  
4. Executive review bottlenecks when no approved boilerplate exists

Note: The value themes in the positioning canvas SHOULD NOT be used as messaging directly. The approved message boilerplate is in the messaging document. Positioning is context. Messaging is execution.

### **Section 1: Positioning Canvas**

The strategic foundation. Everything else in the document must align with this. Provided for context only — not copy.

### **Section 2: Boilerplate Messaging (four formats)**

The One-Liner: One or two sentences describing what you do. Focus on what you are and the greatest benefit you deliver. Bonus: give a hint about who you are for.

The One-Paragraph Elevator Pitch: One paragraph: what you are, top 1–2 value points you deliver, indication of target market. Bonus: some proof you can deliver the value you claim.

The 100-Word Description: One to two paragraphs: what you are, top 2–3 value points, proof you can deliver that value, indication of target market.

The 500-Word Description: Four to five paragraphs: what you are, longer description of top 3–4 value points, proof, target market indication. Can also include: customer names, brag-worthy statistics (number of users, usage metrics — only if clearly exceptional and understandable), awards won.

### **Section 3: Value Points Boilerplate**

Per target segment and champion persona:

Target Segment: The market segment you are actively marketing to. List relevant characteristics, environment, behaviors (e.g., online retailers with more than $10M annual revenue that currently use Shopify).

Champion Persona: Characteristics of the person you're targeting in marketing/sales. Typically the person who develops the short list and makes a recommendation to purchase.

Competitive Alternatives for This Segment: If your solution didn't exist, what would this customer use instead?

Shortcomings of Current Solutions: What does this persona perceive to be the shortcomings of current solutions? What annoys them or makes the current solution less than ideal?

Value Themes (1–3): Per value theme: What is the impact of your product on this persona? Supporting features that enable this value. Proof/evidence that you can provide this value.

### **Section 4: Competitive Messaging**

Approved external responses to competitor claims. Goal: approved wording that can be used outside the company. Generally avoid direct competitor references. Focus on reframing around what you're specifically built for.

Example format:

* Competitor Claim: "Company ABC has the best performing \[product\] for large companies"  
* Our Response: "\[Our company\] measures performance using \[our specific metric\]. For customers that rely on \[our differentiator\], \[our company\] provides better performance than any other offering on the market."

### **Section 5: Approved Customer Assets**

A collection of approved customer-related assets for campaigns, content, and marketing/sales purposes:

* Customer Name  
* Link to Video Assets (long, short, one-slide versions)  
* Link to Case Studies  
* Approved Quotes (captured separately for reuse)  
* Approved Visual Assets (photos, screenshots, etc.)

### **Section 6: Brag Points**

Brag-worthy facts about the company — some used as proof in value points, some as general market credibility. Per brag: Type (award, usage statistic, independent review), Date, Details, Approved Wording.

### **Section 7: Spokesperson Bios and Links**

Per spokesperson: Name, Title, High-resolution photo for print, Low-resolution photo for web, Short Bio (2–3 sentences), Medium Bio (100 words), Long Bio (200 words), Talk Description 1, Talk Description 2\.

### **Section 8: Links to Approved Visual Assets**

Visual asset description, link to approved version, notes for use (including any restrictions on when it can be used).

---

## **9\. April as Strategic Advisor — How to Apply This in the Brain**

When April plays the strategic advisor role (supporting Fletch-led work), apply these specific checks:

### **Positioning Quality Checks**

After any positioning statement is produced, verify:

1. Is the market category chosen so that the differentiated value is obvious within that context? (Not: does it sound impressive. Does it create the right comparison context for the buyer?)  
2. Are the competitive alternatives based on what customers actually short-list — not theoretical competitors?  
3. Are the distinct capabilities truly distinct — or are they table stakes in the category?  
4. Does the differentiated value describe business impact — not product features?  
5. Are the best-fit account characteristics specific enough to actually use as a filter?

### **Common Gaps April Would Call Out**

* Positioning built around aspirational customers, not actual good-fit ones  
* Differentiated value that's really just a feature description (capability ≠ value)  
* Market category chosen for how it sounds rather than what context it creates for buyers  
* Competitive alternatives missing the status quo — "doing nothing" or "manual process" is often the real alternative and gets skipped  
* Best-fit accounts defined so broadly they're not useful as a filter  
* Positioning done solo, without cross-functional input from sales or customer success who actually know what alternatives customers consider

### **Where April's Framework Differs from Fletch's**

* April places more emphasis on the rigorous team-based discovery process before writing positioning. Fletch is more comfortable with a solo or small group approach.  
* April treats the market category selection as the final output of the positioning process (after understanding alternatives, capabilities, and value). Fletch sometimes starts with category framing earlier.  
* April's sales pitch framework is more structured and sequenced than Fletch's approach to sales enablement.  
* For enterprise complexity, multi-stakeholder deals, and product suites with multiple positioning challenges, April's methodology handles depth that Fletch's frameworks assume away.  
* April is more explicit about separating positioning from messaging. Fletch covers both under "positioning" more freely.

### **Key April Principles to Enforce in Advisory Role**

Positioning is done for customers, not for the company. If the positioning makes the team feel good but doesn't resonate with buyers, it's wrong. The test is always: does this make the value obvious to the best-fit account?

The team exercise matters. Positioning done solo is usually theoretical and wrong. Sales and customer success know what alternatives customers actually consider. Product knows what capabilities are actually distinct. The cross-functional process is not optional.

Value themes ≠ messaging. The translation from strategic value theme to customer-facing message is a separate creative act that requires understanding how the target persona communicates and what language they use to describe the problem.

Test with a sales pitch. The pitch is the fastest way to validate whether positioning actually lands with real buyers. If the sales team can't use the positioning in a real conversation — the positioning is wrong.

