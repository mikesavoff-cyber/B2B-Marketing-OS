# MKT1 MCP → PMM OS Routing Reference

**Namespace**: `user-mkt1` · **Status**: connected (paid)

## Strategy sequence (MKT1 recommended order)

```
company_overview → icp_prioritization → marketing_advantages → perceptions
  → positioning → revenue_levers → big_bets → kpo_goals
```

Track progress: `mkt1_marketing_strategy_setup`

## Full tool catalog

### Strategy foundation
- `mkt1_company_overview` — who you are, what you sell, GTM motion
- `mkt1_icp_prioritization` — ICPs ranked by maturity
- `mkt1_marketing_advantages` — structural marketing edges
- `mkt1_perceptions` — 3–4 market narratives (story stack)
- `mkt1_positioning` — positioning statement (who/what/why/type)
- `mkt1_revenue_levers` — stack-rank 4 revenue levers
- `mkt1_big_bets` — 1–3 coordinated campaigns (fuel + engine + audience)
- `mkt1_kpo_goals` — quarterly KPIs, projects, ops

### Planning & execution
- `mkt1_channel_strategy` — match startup to 6 growth engines
- `mkt1_gaccs` — campaign brief (Goals, Audience, Creative, Channels, Stakeholders)
- `mkt1_paid_checklist` — paid program audit

### Research & competitive
- `mkt1_competitive_research` — full competitive dataset
- `mkt1_incognito_competitive_research` — audience-perspective comparison
- `mkt1_high_growth_b2b_company_list` — live research on ~150 B2B startups
- `mkt1_state_of_b2b_marketing_data` — 100 companies × 100 attributes
- `mkt1_website_examples` — B2B website pattern catalog

### Audits
- `mkt1_homepage_positioning` — homepage vs MKT1 positioning framework
- `mkt1_aeo_audit` — answer engine optimization readiness
- `mkt1_billboard_creative` — creative grading

### Knowledge base
- `mkt1_newsletter` — search MKT1 newsletter archive
- `mkt1_templates` — templates, spreadsheets, frameworks
- `mkt1_linkedin_search` — Emily Kramer's posts and replies
- `mkt1_skills_list` — browse all available skills
- `mkt1_changelog` — recent MCP updates

### Meta / skill system
- `mkt1_marketing_strategy_setup` — progress tracker (does not run exercises)
- `mkt1_mcp_help` — troubleshooting
- `mkt1_skill_build`, `mkt1_skill_review`, `mkt1_skill_publish`, `mkt1_skill_maintain` — skill lifecycle

## PMM specialist mapping

| Specialist | Lead MKT1 tools |
|------------|----------------|
| Market Research | competitive_research, incognito_competitive_research, state_of_b2b_marketing_data |
| Positioning & Messaging | positioning, perceptions, homepage_positioning |
| GTM Strategy | channel_strategy, big_bets, revenue_levers, gaccs |
| Sales Enablement | competitive_research, incognito_competitive_research |
| Product Launch | gaccs, big_bets, kpo_goals |
| Customer Marketing | website_examples, state_of_b2b_marketing_data |
