Hey there. My name is Andy McCotter and I'm your instructor for this course on competitive intelligence.

 In this lesson, I'll introduce you to the concept of competitive intelligence and how it can better inform your product marketing efforts. By the end of the lesson, you'll understand what competitive intelligence is, how it can help your organization, and how it can help you in your overall professional career. 

So let's start with the big question what is competitive intelligence? Competitive intelligence is researching and discovering insights relating to competitors in your industry. The more competitive intelligence you have, the more clearly you'll be able to differentiate from those competitors to your ideal customers. If you work in a large organization, it's possible that you could have dozens of competitors multiple categories that are trying to take wallet share. 

On the flip side, if you work for an organization targeting only one audience, then you're likely competing against a smaller collection of vendors. But you'll notice that competitors are involved in both of the scenarios that I outlined. Infinite number of other solutions that your ideal customer could choose, regardless of how niche your product is. Now, with that in mind, let's dive into how competitive intelligence can help your organization. 

Let's lay out a few example scenarios here, and I'll start with the sales team first. If you clearly understand your competitive landscape, you can train your sales team to exploit a competitor's lesser known weakness on a sales call. Do that fluently and repeatedly, and your competitive win rate will go up. That's a direct connection to positively impacting your organization's revenue right there.

 Let's talk about the product team. With a strong understanding of the competitive landscape, you can advise your product team to prioritize aspects of their roadmap. Maybe you have a feature that's weaker than a competitor's for a number of reasons. Find out how much revenue that feature is responsible for and why it's weak week compared to competitors. If you bring that to your product team, that can help your entire organization close the competitive gap for the category leader. 

Last example even as a product marketer, you can inform your C-suite of trends that are occurring in the competitive landscape. New trends and innovations are happening constantly that businesses need to adopt in order to stay relevant. Your insights could lead to the company investing in developing a new product, targeting different personas, acquiring another company. The possibilities are endless. 

Now, last but not least, let's chat about how competitive intelligence can help you in your overall career. 

Once you get started, you'll notice that many competitive intelligence best practices can be recycled into other areas of your life and career. It teaches you to flex your critical thinking skills and ask yourself why a competitor is making a specific move. What it means for your business. It teaches you to collaborate with different teams that prioritize different initiatives. And through these interactions, you'll get a more holistic view of your company, which is significantly better than working in a silo. 

Also, it teaches you to communicate with your C-suite, which if you're watching this course and investing in personal growth, then I'm betting that being seen by that group is of value to you. So hopefully you can now see the potential of competitive intelligence and the benefits that come from researching and discovering insights related to the competitors in your industry. It's one of the few functions that can impact nearly every department sales to product, to marketing, to the C-suite. And hopefully you understand that the skills obtained when conducting competitive intelligence, such as critical thinking, cross-functional communication, are all invaluable in your professional career. 

Throughout the rest of the course, we're going to dive deep into competitive Intel best practices. And whether you're building a new program from scratch or trying to judge up an existing one, there will be plenty of examples and materials to help you connect the dots. Thanks for watching and we'll see you in the next lesson.

