You're building your ICP wrong  
Why everyone thinks about target markets incorrectly (and how to fix it)  
If you want to sound smart and make a founder nervous, ask:  
“Who is your target market?”  
Newer founders will sweat and struggle to respond.  
More experienced founders and marketers will say something like this:  
Target Market:  
Business Model: SaaS companies  
Geography: Europe  
Industry: EdTech  
Size: 500 to 5,000 employees  
This is known as “firmographic segmentation.”  
The most common way we slice and dice the broader market is with details related to the firm (i.e. the business).  
And boy, do we love firmographics in B2B.  
Want to start building a cold email sequence? Apollo needs firmographics.  
Want to run LinkedIn ads? The ad manager immediately asks for… firmographics.  
The entire concept of “account-based marketing” requires choosing a set of companies that match (you guessed it) a set of firmographic criteria.  
If this is so common, it must be a good practice, right?  
Wrong.  
The firmographic trap  
Here's a simple thought experiment.  
Imagine you're selling a SaaS tool that helps land event sponsorships.  
You define your target market firmographically:  
“marketing leaders at Series B startups with 50–200 employees.”  
Now, picture you find someone who fits that description perfectly.  
They work in marketing. It’s a Series B company. The headcount checks out.  
By your own definition, this person is your target customer.  
You send them a cold LinkedIn DM and get this response:  
Why did this happen?  
To put it simply:  
Just because a company matches a set of business attributes does not mean its employees will need your product.  
A better way to think about markets  
Instead of starting with firmographic attributes, start with energy.  
Not woo-woo energy. We’re talking about the activities, behaviors, and unmet desires that signal if someone could use your solution.  
We break potential buyers into three groups. We call them M1, M2, and M3.  
M1: Potential energy  
These are people who have a desired outcome that your product could fulfill, but they're not doing anything about it.  
They're stuck. The desire is there, but there are roadblocks in the way.  
Duolingo is a textbook M1 company.  
Eighty percent of users weren’t trying to learn a language before signing up.  
They had the desire (I wish I could learn Spanish), but the barriers were too high.  
Tutors were too expensive, or they couldn’t find time in their busy days.  
Duolingo came along and unlocked the trapped value with two core messages:

1. Duolingo is free  
2. Duolingo can be done during your commute

M2: Kinetic energy  
These are people who are already doing the activity your product addresses… but in a worse way. They're actively expending effort, but not using your type of solution.  
Your job is to redirect that existing energy.  
DocuSign launched for an M2 market.  
People were sharing and signing documents… but on paper.  
All they had to do was tell people they could accomplish the same task in a much simpler way (electronically.)  
M3: Captured energy  
These are people who already have your type of product or recently evaluated it in depth.  
They know the category and its players. In that sense, they’re mature. However, they chose a competitor.  
Your job is to steal market share from them.  
Figma launched straight at Adobe users.  
They entered a crowded, mature market and made the argument:  
you already have this type of tool: ours is better.  
This matters more than you think  
Each of these groups requires a completely different value proposition. Companies get into serious trouble if they don’t match the message to the segment.  
Let’s say you need to market a CRM to each of these groups. What should you say?  
To a prospect who isn’t tracking leads (M1):  
“Our platform will help you finally keep track of every lead.”  
To a prospect using spreadsheets (M2):  
“With our platform, you can skip manual updates for good.”  
To a prospect using Salesforce (M3):  
“Salesforce is clunky. Our CRM is a delight to use.”  
What happens when you mix up these messages?  
If you tell the Salesforce user they'll "finally be able to track leads," they’ll think you’re crazy. They’ve been tracking leads for years\! In a powerful tool\!  
If you tell someone who’s never tracked a lead that you have an “enjoyable CRM,” they’ll say, “What’s a CRM?”  
A good message aimed at the wrong group becomes a bad message.  
Most companies don't see their segments this way, which leads to an even worse approach: trying to speak to them all at the same time. This is one reason you end up with homepages that say “Grow you business\!” as the core message.  
“But all three of those groups exist\! Can’t I go after all of them?”  
Technically, you can.  
But it will require three completely separate go-to-market campaigns saying three separate things to three separate groups.  
Can you do that in a startup?  
Can you actually win all three segments before you burn through your runway? The answer—more often than not—is no.  
Smart founders and marketers prioritize one group over the others to make the most of their resources.  
Choose one segment, devote 60 to 80% of the GTM budget to it, and watch actual results appear.  
There are certain company dynamics that allow you to ignore the above advice (i.e. you have a famous founder, you’ve raised gobs and gobs of money, your product has virality built into it, etc.)  
But for the rest of us mere mortals, let this be a starting point to help you get way more bang for your buck in your GTM.  
Layering on firmographics  
Maybe you’ve read this far and are thinking “so I should use no firmographics at all??”  
Firmographics aren’t inherently evil — they are just a bad starting point.  
Once you’ve defined an M1, M2, or M3 group, you can absolutely layer on additional firmographics to further narrow your segmentation.  
You may realize that SMB tends to like your solution more than the enterprise. Add it in\!  
Or maybe sales teams are more likely to be doing the activity and you want to call them out explicitly.  
Go for it\!  
Just make sure you don’t forget the most important element:  
starting with energy related to your type of solution.