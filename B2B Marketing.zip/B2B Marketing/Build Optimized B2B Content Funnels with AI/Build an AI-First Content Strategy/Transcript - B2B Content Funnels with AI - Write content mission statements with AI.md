Now we're going to step back and talk about content strategy. We're going to open up the we're going to start with the the reason we publish and the content marketing mission statement. And as we do so, we're going to lay the foundation for a content program that is much more likely to drive outcomes. This is something that not everyone has done yet.

I think there's a simple format for creating a content strategy. If you create a content program that a content strategy that has a documented content marketing mission statement, which is not the mission for your your company, it is the mission for your content. And in that, in that way, it just has to simply specifically define the target audience.

The topics that you publish and the reason they should care for the what's in it for them, the benefit to the reader. So that is my template for our content strategy, which I encourage you to write. There's lots of research that shows that companies that publish, a content strategy, not just have it in a drawer but publish it, are more likely to report the results.

So this is, this is something that is a foundation for all future publishing and a way to keep your brand on track. So this is a template for creating content, mission statements. They include, those three things the target audience, the topics, the benefit to the reader. And I'm going to ask it to create a content strategy for my target audience.

And my test for a good one is that it is repurposed as an email signup call to action. That that audience information. Why benefits information? Why when it's explicit, it's basically the perfect element in an email signup subscription

call to action.

So we're going to make sure that the content strategy has these things. And we're going to validate its effectiveness by repurposing it as an email signup call to action. That's what I'm asking for the I. And it comes back I think it's pretty good. This is for those contractors. Again, get weekly updates on code changes, new tools and smarter installs.

Sounds okay. Yeah, I like that. It's certainly better than a lot of the terrible emails, sign up calls to action that you see all over the internet, but maybe we can improve it. We don't believe in our prompts until they have been tested, so I'm going to now test that prompt. That was just a draft. It's a it's a change.

It's a moment for all of us when you begin to embrace this idea. Every prompt you ever wrote was just a draft. And I can improve that draft. So I'm happy to share with you now my prompt improvement prompt. This is a simple way to get a point of view from the AI and how to make that prompt, more comprehensive, and more performant.

Improve the following prompt for clarity and structure. Your goal is to make a reusable prompt, and then you simply copy and paste in the prompt. So what I took with that prompt that I had written and asked it to iterate, improve that prompt for clarity and structure, paste in that prompt. What do I get back? The revised prompt is actually much more concise.

I was surprised I thought it would be longer. That revised prompt is it better? I haven't I haven't tested it yet. I'm going to look at them side by side. Two browser windows, side by side. I'm auditing. I'm looking back and forth and I see the change specific benefit to the reader. I agree that little word might make a difference.

Practical application I agree that little word might make a big difference. Actionable newsletter sign up. I totally agree that might make a difference. And then when I go test the output of those prompts and look at them side by side, compare. This was simply that extra step of using the prompt improvement prompt where the original I thought was okay.

Remember we we liked it weekly updates on code changes, new tools, and smarter installs. Look at the revision weekly tips on tools, tech, and tactics that actually make your Hvac jobs easier. That looks better to me.

No fluff. Just the stuff that helps you win more bids and get paid faster. I think our rugged AI contractor guy would probably like that, right?

It's a good bit. That sounds like it's very, very well aligned. That was the only difference. We took that extra step and now the the output is dramatically better. So that mindset, that idea, that approach is part of what we are going to do together forever. After

to get better results from AI, we are moving up the AI proficiency scale and now we are fully embracing prompt engineering.

The engineering mindset. Everything we do must be tested. Everything we do could be better. I can help us do it better. And then that becomes a shareable prompt that we can use on the team. So it's a strange, it's a moment when you realize that, AI isn't just good for output, but AI is good for using AI for better output.

So. And now that's worthy of going into your shared prompt library. It is not yet worthy, because if you make some these are like functions. It's like code. This language has, you know, a business application. And if you were to use it again and again or have the whole team use it or shared across your organization, you don't want to share something that hasn't been fully that fully vetted.

That's not it's not ready. It's not ready. Okay. So we've got a little bit of content strategy. We've learned better ways to use AI. We're thinking about ourselves, about skill progression. We're embracing the future, moving away from disruption toward opportunity. And now we're going to use AI for some specific, topic research

