I'm going to add now, one more, one more, which is a bit a bit broader, but I think relevant to all of us. Just checking for specificity. I believe this for years. Specificity correlates with conversion. A lot of pages fail because they're just sort of generic.

They don't really get they don't explain in detail what the company does. So I've got it, for example, here, this is an architectural engineering firm.

Let's read the header together. Unmatched talent leads to extraordinary results okay. We're a web design company. I can say that same thing. Millions of companies could say that exact same thing. It's not specific to the visitors needs or this brand.

It's just taglines. Two problems. The tagline doesn't tell the visitor that they're in the right place. Problem to the taglines. Taglines don't train the eye. Hey, I can't read that and understand that you're you're in this business category, right? It's a missed keyword opportunity for SEO. It's a missed training opportunity for AI, and it's a missed UX conversion.

You know, reducing your bounce rate, opportunity for the humans. I'm sorry. If you're a brand marketer that loves precious copywriting and you work very hard on those eight words, but if anything on your page is something that literally any business could say, I think you could maybe, maybe, work harder on it. It gets worse further down the page.

These subheads who we are, project services, community and culture. I suspect, hate them. All of us on this call. Anyone thinking this course could write those same subheads scan down your page and ask, could a startup born yesterday make the same page? If that's true, that we don't really differentiate ourselves at all. Look at the images.

Okay, now the specificity audit is a general audit and does not require a persona, although probably every prompt you use can be improved by writing in your persona. I'm just going to give it that page and I'm going to write a specificity prompt audit this page. There's the screenshot, audit this page for for the specificity of both the text and the images.

Right. And the header, the hero, the subheadings, the navigation labels and calls to action. Is it vague or specific for each element, provide detailed recommendations for improving the, the content, specifically identifying words and phrases that need to be more descriptive or clear. Does the header clearly communicate what the company does or is it vague? Do the images directly relate to the industry or other generic?

Are the TOS and subheads descriptive and specific, or do they use vague terms? So this is a this specificity audit looks at these pages from multiple perspectives, including the navigation labels and the calls to action. If you told me three years ago, four years ago that you built a tool that would do this audit for you and, and that I could buy it for $100 a month, I would have paid for this.

And many of these prompts are sort of, similar to software. The language is like code that this is a function. It's an audit function that you can run. It needs a certain input. It has to be constructed carefully. But the outputs are literally the kinds of things that, all of us used to pay for is like a SAS product.

I could have done this. I've always wanted this product. But now I can do it by simply copying and pasting in a to the full page screenshot. And it gives me results right away. And the result, as you can imagine, you know me now. Well, I want ratings. The header, unmatched talent leads to extraordinary results. I don't think that's very specific.

I think anybody could write that. How about this one? Engineering and architecture for industrial infrastructure leaders. So much better. Okay, I don't need to test that. If it's a bug or a problem, don't test, just fix it. I'm going to call this almost like a bug. You know, unmatched talent for extraordinary results. Engineering. You're calling your visitor a leader.

That's like an aspirational H1. I love it very much. Delivering precise, compliant engineering for industrial or municipal facilities. Hey, remember the first question I've ever visited? Every web pages? Am I in the right place? Clearly you are. Images. We have stacked hands for teamwork. Oh, no. Why? Why do we do that? You're talking to engineers. What are we?

Engineers like projects. What do engineers like? Diagrams. Visuals. We keep going. This is the biggest gap. The Subheads are who we are. Projects, services, community and culture. It comes back with far better, I think. Far better. Subheads. If those violate your sensibilities by being so long as to wrap on a mobile device first check your mobile traffic.

My site has, 92% desktop. It'll be different for you, but measure the impact if you're concerned about mobile visitors. But then also, you know, this isn't about us and our design sense. Our design esthetic preferences. This is about the visitor and then finding what they would need. So I would absolutely consider very long subheads if it if it is just what the visitor has to find to get their answer.

Navigation labels about market services projects. Okay. Hold on the suggestions far more specific industries and facilities. Engineering and architecture services. I was a bit surprised it like this one here. A lot of culture, community and culture and blog it says don't change those. It says those are clear. It's kind of surprised to see a generative. I would say that to not recommend something.

It says, yeah, those are keep those they're clear enough. So, it also this same prompt gives you basic audit, CTA recommendations, which I like quite a bit. Get in touch. The changes to schedule, the consultation that reduces the perceived investment. You're just scheduling a consultation. If you keep your wallet in your pocket, you're not spending money yet with our engineering team.

That raises the perceived, benefit, right? The cost seems low and the benefits inside. That's how you manipulate the ROI calculation your visitors doing in their mind. Schedule a quick call with with an engineer. Schedule a quick call with the structural engineer. That sounds great. That's really what I need to do. I want to talk to an expert, and I just want to have a call like low perceived investment.

It comes back with the ratings. So the specificity audit sort of wraps up a lot of what we just did. If we believe that specificity is, in fact something that would correlate with conversions, then, we should believe that, an audit for that, we're going to take, some questions here. But before I do, I want to recap everything we've done on one slide.

I mostly have not been looking for efficiencies. It's not what we did today. I care about efficiency and I'm busy. We're all busy, but finding efficiencies is not my mental mindset. When I use I. I love finding deficiencies and looking for gaps and using AI to fill those and using AI to spot those gaps, and then using all my best expertise and tools and and knowledge and skills to fill those gaps.

If I can make something that works hard, work a little harder, it's like I make content that's engaging a little bit more engaging. If I can make that page add a bit more clarity, if I can make that call to action a bit more compelling. And many of those things are exactly what I need to do anyway, to better train the AI to believe that were the best option for the for the the prospect your audience.

Right now, as we speak during this conversation, they are asking, there are people out there trying to find you. Have you made your site sufficiently comprehensive, complete, almost exhaustive to sufficiently train the AI to persuade the visitor to trigger the action? This is how we grow. This is all growth. I'm totally focused on growth, but it's not. It's not just for speed.

I think that our our best growth opportunities will come from finding deficiencies. So, we're going to recap, but I want to I want to suggest and just remind us that, you know what we did, we we we found gaps in articles. We found gaps on the internet. We found gaps in our own publishing. We found gaps in what I noticed about our brands.

We found gaps in our key pages, in answers, in evidence, and in calls to action. That's what we did here. There's also opportunities to look for gaps, in other places. What's missing from anything else? What's missing from your strategic, from your home page or landing pages or email nurture sequence or case studies or your sales deck.

Give either persona and your sales stack right. So you could use it for any marketing asset at all, or in fact, any strategic document. What's missing from your ISP's? What's missing from your messaging framework or your value proposition, or your content strategy? This is an exciting time to do digital, because there you'll find that, the sort of gap analysis audit prompts persona driven, points of view on things.

I think that quality focus is what will, both improve your skills, which we all did together and also, drive greater performance.

Phil, I think we have just enough time here for a few questions, if you'd like. Yeah. One question might be a bit bigger, because Holly was asking if you have any more examples of landing pages or pages where, the order of elements and everything is like, perfect, you are most alike examples so far from your apps.

I'm not sure if that is something that you have ready right now or something that you can share later. And a message to all users. I think it's a, it's a it's a very interesting question. And again, we need to be comfortable with ambiguity because it's not true that 100% of our visitors have the same message, have the same, prioritized questions.

So it's, I think that the first thing should typically be the category of the place they are telling them that they're in the right place. I also think that evidence should be high above the full, knowing from seeing millions of scroll heatmaps, that that only a only a percentage of people will click will scroll at all. So I want the where are you?

Are this the name of the page, the descriptive label for the URL at the top. And I want visual credibility somewhere high on the page. But after that it's a judgment call. It's difficult. There's not one right answer. CMS will allow you to move up, you know, by dragging and dropping, typically, move around the order of the page blocks.

But this could be, a conversation you could have with your eye. And assuming your persona is correct, it will give you a point of view. But that is not something for which there is a single correct answer. He used the word perfect. I don't believe in perfect. It's not possible, right? There isn't. Because not about not all of our visitors are the same.

People make decisions for all kinds of weird reasons. You know, there's everyone has different concerns. It's often true that people make decisions for their own personal reasons. They want to be seen a certain way. So anything that aligns with positioning them or indicates even adjacent that they that this is going to, you know, make them shine inside their organization.

But I don't know that I would even look for perfection. I would look for hypotheses. And then also just make sure that, your strongest proof points are, are being seen by, as many people as you can by check your scroll heatmaps, but then prioritize. I think some of those, some of the, some of your best I it it's great question.

Then Casey was asking from your perspective, will we start getting a deeper look into the AI platforms and how they work in the future? I think that they will remain mostly transparent where you can ask them about your brand, ask them about your competitors, have it created by your guide, have a create a comparison table. I don't see that changing because that's simply how the users will do it as well.

And mostly in that in that scenario, asking for a more structured version of what your user, your future prospect, is likely doing already. The there are limbs that you can like. Llama you can download and run on your computer. I mean they're just it's there's open source lens. So, what are the big questions that I still have?

And we may and we'll be very, very difficult to answer. Hard for media. But imagine the research that would expose these. What type of prompts, trigger responses where I can just rely on it's based training versus which types of prompts ask for more and trigger. I had to go search some prompts. It just uses it's based creating some prompts.

It will actually go search right I searching on behalf of users. What is the difference? You know when does it do that I don't know and and I would love to understand that better. Another question I have that would be difficult to analyze which pages is how deep does it go? Should we be putting some of these key messages on these like pages close to the root?

How much has to go on the home page? Is it possible to make a page? That's the minimal UX, but maximum information that's specifically made to train the AI unknown, maybe unknowable? Very hard to tell, hard to chase the technology. It's changing very quickly. So I have some big questions, but I don't, I'm not I'm going to be okay if I don't get the answers because I'm leading with these hypotheses and taking kind of a human first approach.  
