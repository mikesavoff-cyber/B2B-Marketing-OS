So what is a North Star Metric, and why do you need it? That's what we're going to cover in this Letson. We're going to talk about the importance of having an North Star Metric. And how to make sure it relates to the y behind your brand. We're also going to learn about why your North Star Metric should never, ever, ever be revenue.

So let's s in. It all starts for your business with your North Star Metric. The way I like to imagine this is as a treasure map. You've got your teams in different places, but if you know what your x is, everyone will eventually get there and find their way to it. And you're all starting in different places with different challenges and things, and that's why these teams are split up, but they're all working towards an x if they know where it is.

And so having an X on your map will guide it, because if there's no clear X, every team will be working different directions to different places. Now, A X alone is not enough to line them. You have your individual goals across the time. And that helps to ensure that you're not over simplifying it, but that you're also helping people step by step.

Because that is one of the major arguments against the North Star Metric is that it oversimplifies it. And if you were to use it as does it help us reach our North Star Metric, yes or no, and deciding your task based on that, I would 100% agree. You can't work that way. But if you use it as a way to work backwards to setting the steps along the way and the metrics along the way, to get there, then it actually works really, really well in aligning everyone.

And those markers, they might be OKRs, there might be a growth levers, but they help you work towards that goal. If you think about it, for example, Netflix, they might have time spent enjoying Netflix as their North Star metric, because more time on Netflix means more video consumed, more chance that they talk about it to other people, more chance that they renew their subscription, and more value added for both sides.

But you probably can't stay on that metric because that's the output metric. You're going to work backwards from knowing your North Star metric to work out the main KPIs that drive it and help support it. So in Epix case, it might be that increasing watch time per session is the main KPI of that, and also increasing the number of sessions, because together, that improves the amount of time spent.

But even those KPIs have KPIs that lead into them and input metrics that help them. So, for example, for the increasing number of sessions per user, The number of new sessions started impacts it. The number of returning users impacts that. And the same with the second one with time watch. If there's a lower time watch between sessions, or if there's an increased suggestion relevancy, it might help to drive increased time watch.

With your North Star Metric, it's not that that really becomes the only metric you're steering on, but rather it's the output metric that your growth model and all your other KPIs should be supporting to help you achieve and helping to line your teams.

Even Gar who does the breakout growth podcast, together with Shean Ellis said this about it when I talked to him about North Star Metric. He said a well considered North Star metric can help unlock a company's ability to accelerate expansion across its full growth engine.

And the reason why is because it inherently captures the value that's being delivered. And so aligning those teams can help drive meaningful focus towards a shared mission. So brings together all your different teams by having them have the same metric in mind, and it also reduces competition or misalignments between teams because they learn to understand how their metrics are helping reach the same goal.

So what is a North Star metric? It's that high level metric that guides your team, you're staring your horizon or your x on the map where you want to go to. But it should not be revenue, rather something that drives value to you and your own customer, something that so people aspire to achieve, and that excites them.

It shouldn't change over time. It really should be the same. There are exceptions. For example, if you've made a huge pivot as a company or you set it pre product market fit it might change. But in general, it will be the same for years and years.

So make sure that you also set it to something that will be relevant, not just now, but in the future. And what's also really key is simplicity. Make it easy for everyone to understand so that they can keep it top of mind and focus on it.

S s put it this way. It's a single metric that best captures the core value of your product delivers to customers. With Netflix, they're streaming video. So counting the amount of time watched makes a lot of sense because that's a value that people are getting out of it and watching it.

Not the number of subscriptions or the revenue, because that doesn't capture if they're actually engaging in the product. So why not revenue? Well, revenue isn't actually focusing on that value on the customer side. It isn't focused on adding value. It can also result in very short term thinking. Huge discounts might improve revenue, but it doesn't mean you're helping more customers or driving long term value for either the company or the customer.

And of course to metric may or should result in revenue to drive value for the company, but it isn't the end goal. I also think of it in terms of what excites the team. I've mentioned that before, but I find it so important. I've worked in an agency, and sometimes there the focus can get very easily on revenue, and it's not a very motivating environment.

Instead of thinking about, like, what change you want to see, what value you want to see, how you want to help people, it also excites your team, which revenue doesn't do.

So let's walk through some examples of what a North Star Metric could look like in different types of organizations.

Starting with a SAS company. Here often North Star Metric is the core value of that software. It's what ensures customers stay and get value from the platform. So for slag, it could be that they focus on the number of messages sent. As this ensures that people are actually actively using it within there. And that it's actually replacing, for example, e mail within that organization.

So by checking number of messages being sent, it will make sure that they're actually seeing, like, a, are people using it frequency, are people using it more.

For an e commerce business with a physical product, it's really, really hard to be honest to know the usage. I've had a lot of people so challenge, like, a, should we then focus just on returning customers or like, second to third orders to know that they've actually got the value that they're coming back?

While that sounds great in practice. It's a very hard North Star Metric to work with because it has such a strong lag. As a result, you won't get a good feel for what is and isn't contributing to it because there's so many different factors, and it takes a while to show.

So instead, I tried to suggest to use something that suggests that they're using in it or getting value from it. So D Cura, for example, is an essential oils company that I worked with, and they focused on b2b and b2c. We have an ECMA store. We ended up deciding that litres of oils bought was a good North Star Metric because we couldn't control if people using them.

But we knew that returning customers tended to buy so by focusing on the number of litres used, it encouraged us to focus on getting more returning customers back to value those bigger BTB companies, but also to help customers learn how to use their oils, because a lot of them were only using it in one way, but didn't realize they could use es central oils for other things as well.

Moving on to two other types, apps and marketplaces. So if Apps, it's about what is the key value of the app and a measure that kind of multiplies as they use it more. I like the multiplication of them using it more because it really focuses on artic coming back, getting frequent usage out of it, first is just opening it and not getting anything out of it.

So if we take something like Spotify, it could be the amount of time listened because that will capture all the different mediums that they have from music, podcast, to longer consumption. It would also encourage Spotify to really focus on getting people back and finding more music they love. They do a lot for things like their DJ function, their playlist, and that all helps to drive number of minutes listen.

With a market place, it's a bit trickier because you have those two different sides. So it's trying to work out what is a metric that reflects both sides are getting long term value. I really preferred this over having two separate metrics, one for each side of the market, because that just splits the two parts out rather than looking together at what is needed and what part should be a focus point.

So for UBA, something like rides per week could really encourage them to get users to come back more frequently, and also make sure that drivers are getting enough rides evenly throughout the month. Because imagine if they did something like rides per month, and there was just one period of the month that there were lots of rides and another period that wasn't, it wouldn't be valuable for their driver's side of it.

But on the other hand, daily might be very tricky because there might be differences in certain days of the week, having more drives, or certain days there being very few drivers who drive on that day. And as a result, that would be quite variable, and you'd get caught up in these little changes versus focusing on the overall trend.

So to recap what we covered here, your North Star Metric is your guiding metric. It's one metric that your whole organization focus on. It's your long term goal, and it helps you to ensure that you're focusing on the right things to drive value for your customers and organization. And it should never ever, ever be revenue.

